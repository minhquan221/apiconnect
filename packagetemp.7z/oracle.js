var oracledb = require('oracledb');
var logFile = require("./readFile").FileStream;
var logFilelastIDSync = "./idsync.txt";
var mongoData = require("./mongodata").mongoData;
var connectionORAC = {
        user: "ocbcrm",
        password: "123456",
        connectString: "10.96.62.10/crmpilot"
};

var oracleConnect = (exports.oracleConnect = {});

oracleConnect.GetCustomerSync = async function(storeandcollection, pageindex, pagesize, tableName){
	console.log('Start Get Oracle Data');
	console.log(storeandcollection);
	var storename = storeandcollection.storename;
	var collection = storeandcollection.collection;
	var connection = await oracledb.getConnection(connectionORAC);
	var mongoDataConnect = await mongoData.ConnectData();
	var i =  0;
	//var lst = [];
	try
	{
		var parameterObject = {
			p_PageNum: { dir: oracledb.BIND_IN, val: pageindex, type: oracledb.NUMBER },
			p_PageSize: { dir: oracledb.BIND_IN, val: pagesize, type: oracledb.NUMBER },
			v_refCur: { dir: oracledb.BIND_OUT, type: oracledb.CURSOR }
		};
		var query = "BEGIN " + storename + "(:p_PageNum,:p_PageSize,:v_refCur); END;";
		var result = await connection.execute(query, parameterObject);
		var row;
		var header = result.outBinds.v_refCur.metaData;
		//var arrayRow = await result.outBinds.v_refCur.getRows(pagesize);
		
		console.log('Begin insert to Mongo');
		// arrayRow.forEach(row =>{
			// console.log(row);
		// });
		while(row = await result.outBinds.v_refCur.getRow())
		{
			if(row == null || row == undefined)
				break;
			i++;
			var objectdata = {};
			for (var j = 0; j < row.length; j++) {
				objectdata[header[j].name] = row[j];
			}
			//console.log(objectdata);
			var listmanageruser = await oracleConnect.GetManageData(connection, objectdata["Custgroup"], objectdata["BranchCode"], objectdata["AreaId"]);
			objectdata["MANAGERUSER"] = listmanageruser;
			var listoppotunities = await oracleConnect.GetOppotunities(connection, objectdata["CrmCustId"], objectdata["CifNo"], objectdata["AccountOfficer"]);
			objectdata["OPPOTUNITIES"] = listoppotunities;
			var esx = await mongoData.InsertData(mongoDataConnect, collection, objectdata);
			console.log('done record ' + objectdata["_id"]);
			//lst.push(objectdata);
			if(i == pagesize)
				break;
		}
		console.log('End insert to Mongo');
		//await result.outBinds.v_refCur.close();
		//mongoDataConnect.close();
		//connection.close();
		console.log('Finish Get Oracle Data');
	}
	catch(err){
		console.log('GetCustomerSync ' + err);
	}
	finally{
		await result.outBinds.v_refCur.close();
		await connection.close()
		//result.close();
		console.log('Connection Oracle closed');
		await mongoDataConnect.close();
		console.log('Connection Mongo closed');
		return i;
	}
	
};

oracleConnect.SyncSingleRecord = async function(connection, recordid, recordtablename, runId){
	//var connection = await oracledb.getConnection(connectionORAC);
	//console.log(connection);
	var mongoDataConnect = await mongoData.ConnectData();
	var i =  0;
	//var lst = [];
	try
	{
		var parameterObject = {
			p_Id: { dir: oracledb.BIND_IN, val: recordid, type: oracledb.STRING },
			p_Table: { dir: oracledb.BIND_IN, val: recordtablename, type: oracledb.STRING },
			v_refCur: { dir: oracledb.BIND_OUT, type: oracledb.CURSOR }
		};
		var query = "BEGIN GETRECORDSYNC(:p_Id,:p_Table,:v_refCur); END;";
		var result = await connection.execute(query, parameterObject);
		var row;
		var header = result.outBinds.v_refCur.metaData;
		//var arrayRow = await result.outBinds.v_refCur.getRows(pagesize);
		
		console.log('Begin update to Mongo');
		// arrayRow.forEach(row =>{
			// console.log(row);
		// });
		await mongoData.DeleteData(mongoDataConnect, recordtablename, recordid);
		while(row = await result.outBinds.v_refCur.getRow())
		{
			//console.log(row);
			if(row == null || row == undefined)
				break;
			var objectdata = {};
			for (var j = 0; j < row.length; j++) {
				objectdata[header[j].name] = row[j];
			}
			//console.log(objectdata);
			var listmanageruser = await oracleConnect.GetManageData(connection, objectdata["Custgroup"], objectdata["BranchCode"], objectdata["AreaId"]);
			objectdata["MANAGERUSER"] = listmanageruser;
			var listoppotunities = await oracleConnect.GetOppotunities(connection, objectdata["CrmCustId"], objectdata["CifNo"], objectdata["AccountOfficer"]);
			objectdata["OPPOTUNITIES"] = listoppotunities;
			var esx = await mongoData.InsertData(mongoDataConnect, recordtablename, objectdata);
			
			//lst.push(objectdata);
		}
		console.log('done update record ' + runId);
		var logResult = await logFile.WriteFileAsync(logFilelastIDSync, runId);
		if(logResult == 0)
		{
			console.log('error write log update record ' + runId);
		}
		
	}
	catch(err){
		console.log('SyncSingleRecord ' + err);
	}
	finally{
		await result.outBinds.v_refCur.close();
		//await connection.close()
		console.log('Connection Oracle closed');
		await mongoDataConnect.close();
		console.log('Connection Mongo closed');
		return i;
	}
	
};

oracleConnect.GetLastID = async function(){
	var connection = await oracledb.getConnection(connectionORAC);
	var result = 0;
	try
	{
		var parameterObject = {
			v_id: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER }
		};
		var query = "BEGIN GETLASTIDSYNC(:v_id); END;";
		var querydata = await connection.execute(query, parameterObject);
		if(querydata != undefined)
		{
			result = querydata.outBinds.v_id;
		}
	}
	catch(err){
		console.log('GetCustomerSync ' + err);
	}
	finally{
		await connection.close()
		return result;
	}
	
};

oracleConnect.GetSyncCust = async function(currentid, lastid){
	var connection = await oracledb.getConnection(connectionORAC);
	//var result = 0;
	try
	{
		var parameterObject = {
			v_begin: { dir: oracledb.BIND_IN, val: parseInt(currentid), type: oracledb.NUMBER },
			v_end: { dir: oracledb.BIND_IN, val: parseInt(lastid), type: oracledb.NUMBER },
			v_refCur: { dir: oracledb.BIND_OUT, type: oracledb.CURSOR }
		};
		var query = "BEGIN GETLISTIDSYNC(:v_begin, :v_end, :v_refCur); END;";
		var result = await connection.execute(query, parameterObject);
		var row;
		while(row = await result.outBinds.v_refCur.getRow())
		{
			if(row == null || row == undefined)
				break;
			var runId = row[0];
			var recordid = row[1];
			var recordtablename = row[2];
			var arr = await oracleConnect.SyncSingleRecord(connection, recordid, recordtablename, runId);
		}
	}
	catch(err){
		console.log('GetSyncCust ' + err);
	}
	finally{
		await connection.close()
		//return result;
	}
}


oracleConnect.GetOppotunities = async function(connection, custid, cif, oppofficer){
	var lst = [];
	try
	{
		var parameterObject = {
			v_CrmCustId: { dir: oracledb.BIND_IN, val: custid, type: oracledb.STRING },
			v_CIF: { dir: oracledb.BIND_IN, val: cif, type: oracledb.STRING },
			v_OppOfficer: { dir: oracledb.BIND_IN, val: oppofficer, type: oracledb.STRING },
			v_refCur: { dir: oracledb.BIND_OUT, type: oracledb.CURSOR }
		};
		
		var query = "BEGIN SYNCOPPOTUNITIES(:v_CrmCustId , :v_CIF , :v_OppOfficer , :v_refCur); END;";
		var result = await connection.execute(query, parameterObject);
		var row;
		
		var header = result.outBinds.v_refCur.metaData;
		while(row = await result.outBinds.v_refCur.getRow())
		{
			//console.log('is has AccountOfficer custid: ' + custid + ', cif_no: ' + cif);
			if(row == null || row == undefined)
				break;
			var objectdata = {};
			for (var j = 0; j < row.length; j++) {
				objectdata[header[j].name] = row[j];
			}
			lst.push(objectdata);
		}
		//connection.close();
		//await result.outBinds.v_refCur.close();
	}
	catch(err){
		console.log('GetOppotunities ' + err);
		//connection.close();
		//return null;
	}
	finally{
		await result.outBinds.v_refCur.close();
		//connection.close();
		//result.close();
		return lst;
	}
};


oracleConnect.iSExistOppotunitiesCust = async function(custid, cif, oppofficer){
	var connection = await oracledb.getConnection(connectionORAC);
	var resultQuery = 0;
	try
	{
		var parameterObject = {
			v_CrmCustId: { dir: oracledb.BIND_IN, val: custid, type: oracledb.STRING },
			v_CIF: { dir: oracledb.BIND_IN, val: cif, type: oracledb.STRING },
			v_OppOfficer: { dir: oracledb.BIND_IN, val: oppofficer, type: oracledb.STRING }
		};
		var query = "SELECT iSExistOppotunitiesCust2(:v_CrmCustId,:v_CIF,:v_OppOfficer) from dual";
		var result = await connection.execute(query, parameterObject);
		resultQuery = result.rows[0][0];
	}
	catch(err){
		console.log(err);
	}
	finally{
		await connection.close();
		return resultQuery;
	}
};

oracleConnect.GetManageData = async function(connection, Custgroup, BranchCode, AreaId){
	//var connection = await oracledb.getConnection(connectionORAC);
	var lst = [];
	try
	{
		var parameterObject = {
			P_CUSTGROUP: { dir: oracledb.BIND_IN, val: Custgroup, type: oracledb.NUMBER },
			P_BRANCH_CODE: { dir: oracledb.BIND_IN, val: BranchCode, type: oracledb.STRING },
			P_AREA_ID: { dir: oracledb.BIND_IN, val: AreaId, type: oracledb.NUMBER },
			v_refCur: { dir: oracledb.BIND_OUT, type: oracledb.CURSOR }
		};
		var query = "BEGIN SYNCMANAGERUSER(:P_CUSTGROUP , :P_BRANCH_CODE , :P_AREA_ID , :v_refCur); END;";
		var result = await connection.execute(query, parameterObject);
		var row;
		var header = result.outBinds.v_refCur.metaData;
		while(row = await result.outBinds.v_refCur.getRow())
		{
			if(row == null || row == undefined)
				break;
			var objectdata = {};
			for (var j = 0; j < row.length; j++) {
				objectdata[header[j].name] = row[j];
			}
			lst.push(objectdata);
		}
		//connection.close();
		//await result.outBinds.v_refCur.close();
	}
	catch(err){
		console.log('GetManageData ' + err);
		//connection.close();
		//return null;
	}
	finally{
		await result.outBinds.v_refCur.close();
		//connection.close();
		//result.close();
		return lst;
	}
};