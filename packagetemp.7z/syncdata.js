var mongoData = require("./mongodata").mongoData;
var oracleConnect = require("./oracle").oracleConnect;
var logFile = require("./readFile").FileStream;
var SyncTableName = "Customer";
var SyncData = (exports.SyncData = {});
var StoreTableCustomer = "SYNCDATACUSTOMER";
var StoreTableCustomerPROS = "SYNCDATACUSTOMER2";
var Collection1 = "Customer";
var Collection2 = "CustomerPros";
var pageindex = 0;
var pagesize = 10000;
var isSync = false;
var isEmptyData = false;
var rowSync1 = 1;
var rowSync2 = 1;
var logFilePageSync = "./pagesync.txt";
var logFilePageSizeSync = "./pagesizesync.txt";
var logFileSyncFinish1 = "./resultsynccustomer.txt";
var logFileSyncFinish2 = "./resultsynccustomerpros.txt";
SyncData.Sync = async function(TableName){
	//var result = false;
	try
	{
		isSync = true;
		var currentpage = await logFile.readFileAsync(logFilePageSync);
		var currentsizepage = await logFile.readFileAsync(logFilePageSizeSync);
		var SyncFinish1 = await logFile.readFileAsync(logFileSyncFinish1);
		var SyncFinish2 = await logFile.readFileAsync(logFileSyncFinish2);
		if(currentpage != '0')
		{
			pageindex = parseInt(currentpage) + 1;
		}
		if(currentsizepage != '0')
		{
			pagesize = parseInt(currentsizepage);
		}
		if(SyncFinish1 != '')
		{
			rowSync1 = parseInt(SyncFinish1);
		}
		if(SyncFinish2 != '')
		{
			rowSync2 = parseInt(SyncFinish2);
		}
		console.log('Start SyncData page ' + pageindex + ', page size ' + pagesize);
		if(rowSync1 > 0)
		{
			rowSync1 = await oracleConnect.GetCustomerSync({ storename: StoreTableCustomer, collection: Collection1 }, pageindex, pagesize, TableName);
		}
		else
		{
			console.log('done sync table Customer');
		}
		if(rowSync2 > 0)
		{
			rowSync2 = await oracleConnect.GetCustomerSync({ storename: StoreTableCustomerPROS, collection: Collection2 }, pageindex, pagesize, TableName);
		}
		else
		{
			console.log('done sync table CustomerPros');
		}
		if(rowSync1 > 0 || rowSync2 > 0)
		{
			//oracleConnect.GetCustomerSync(StoreTableCustomer, pageindex, pagesize, TableName);
			console.log('Finish SyncData page ' + pageindex);
			var logResult = await logFile.WriteFileAsync(logFilePageSync, pageindex);
			if(logResult == 0)
			{
				console.log('error write log to page index.');
			}
		}
		else
		{
			return;
		}
		isSync = false;
	}
	catch(err){
		console.log('Sync ' + err);
		//result = false;
	}
	finally{
		
		//return result;
	}
};
SyncData.SyncAllData = async function(){
	if(!isSync)
	{
		pageindex++;
		await SyncData.Sync(SyncTableName);
	}
}

SyncData.Interval = async function(){
	var interV = setInterval(async function(){
		if(rowSync1 > 0 || rowSync2 > 0)
		{
			await SyncData.SyncAllData();
		}
		else
		{
			clearInterval(interV);
		}
	}, 1000);
}


SyncData.Synchornize = async function(){
	try
	{
		await SyncData.Interval();
	}
	catch(err){
		console.log('Synchornize ' + err);
	}
	finally{
		
	}
}