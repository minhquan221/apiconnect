var express = require('express');
//var bodyParser = require('body-parser');
var app = express();
//var router = require("./router");
var SyncChangeData = require("./syncrecordupdate").SyncChangeData;

//app.use("/", router);


app.listen(2600, function() {
  console.log("Server NodeJS Listening on port 2600");
  SyncChangeData.SyncData();
});