var oracledb = require('oracledb');
var mongoData = require("./mongodata").mongoData;
var connectionORAC = {
        user: "ocbcrm",
        password: "123456",
        connectString: "10.96.62.10/crmpilot"
};

var oracleConnect = (exports.oracleConnect = {});

oracleConnect.GetCustomerSync = async function(storeandcollection, pageindex, pagesize, tableName){
	console.log('Start Get Oracle Data');
	console.log(storeandcollection);
	var storename = storeandcollection.storename;
	var collection = storeandcollection.collection;
	var connection = await oracledb.getConnection(connectionORAC);
	var mongoDataConnect = await mongoData.ConnectData();
	//var lst = [];
	try
	{
		var parameterObject = {
			p_PageNum: { dir: oracledb.BIND_IN, val: pageindex, type: oracledb.NUMBER },
			p_PageSize: { dir: oracledb.BIND_IN, val: pagesize, type: oracledb.NUMBER },
			v_refCur: { dir: oracledb.BIND_OUT, type: oracledb.CURSOR }
		};
		var query = "BEGIN " + storename + "(:p_PageNum,:p_PageSize,:v_refCur); END;";
		var result = await connection.execute(query, parameterObject);
		var row;
		var header = result.outBinds.v_refCur.metaData;
		//var arrayRow = await result.outBinds.v_refCur.getRows(pagesize);
		var i =  0;
		console.log('Begin insert to Mongo');
		// arrayRow.forEach(row =>{
			// console.log(row);
		// });
		while(row = await result.outBinds.v_refCur.getRow())
		{
			if(row == null || row == undefined)
				break;
			i++;
			var objectdata = {};
			for (var j = 0; j < row.length; j++) {
				objectdata[header[j].name] = row[j];
			}
			//console.log(objectdata);
			var listmanageruser = await oracleConnect.GetManageData(connection, objectdata["Custgroup"], objectdata["BranchCode"], objectdata["AreaId"]);
			objectdata["MANAGERUSER"] = listmanageruser;
			var esx = await mongoData.InsertData(mongoDataConnect, collection, objectdata, tableName);
			console.log('done record ' + objectdata["_id"]);
			//lst.push(objectdata);
			if(i == pagesize)
				break;
		}
		console.log('End insert to Mongo');
		//await result.outBinds.v_refCur.close();
		//mongoDataConnect.close();
		//connection.close();
		console.log('Finish Get Oracle Data');
	}
	catch(err){
		console.log('GetCustomerSync ' + err);
	}
	finally{
		await result.outBinds.v_refCur.close();
		await connection.close()
		//result.close();
		console.log('Connection Oracle closed');
		await mongoDataConnect.close();
		console.log('Connection Mongo closed');
		return 1;
	}
	
};

oracleConnect.GetBigDataSync = async function(storeandcollection, pageindex, pagesize){
	console.log('Start Get Oracle Data');
	console.log(storeandcollection);
	var storename = storeandcollection.storename;
	var connection = await oracledb.getConnection(connectionORAC);
	var result;
	//var lst = [];
	var count = 0;
	try
	{
		console.log('begin: ' + new Date());
		var parameterObject = {
			p_PageNum: { dir: oracledb.BIND_IN, val: pageindex, type: oracledb.NUMBER },
			p_PageSize: { dir: oracledb.BIND_IN, val: pagesize, type: oracledb.NUMBER },
			v_refCur: { dir: oracledb.BIND_OUT, type: oracledb.CURSOR }
		};
		var query = "BEGIN " + storename + "(:p_PageNum,:p_PageSize,:v_refCur); END;";
		result = await connection.execute(query, parameterObject);
		var row;
		console.log('begin read each row. ' + new Date());
		while(row = await result.outBinds.v_refCur.getRow())
		{
			count++;
			//console.log('row number: ' + count);
		}
		console.log('finish read each row. ' + new Date());
	}
	catch(err){
		console.log('GetBigDataSync ' + err);
	}
	finally{
		await result.outBinds.v_refCur.close();
		await connection.close();
		console.log('end: ' + new Date());
		return count;
	}
	
};

oracleConnect.iSExistOppotunitiesCust = async function(){
	//connection, custid, cif, oppofficer
	var connection = await oracledb.getConnection(connectionORAC);
	var result;
	try
	{
		var parameterObject = {
			v_CrmCustId: { dir: oracledb.BIND_IN, val: '24', type: oracledb.STRING },
			v_CIF: { dir: oracledb.BIND_IN, val: '', type: oracledb.STRING },
			v_OppOfficer: { dir: oracledb.BIND_IN, val: '100339', type: oracledb.STRING }
		};
		var query = "SELECT iSExistOppotunitiesCust2(:v_CrmCustId,:v_CIF,:v_OppOfficer) from dual";
		var result = await connection.execute(query, parameterObject);
	}
	catch(err){
		console.log(err);
	}
	finally{
		await connection.close();
		return result;
	}
}

oracleConnect.GetManageData = async function(connection, Custgroup, BranchCode, AreaId){
	//var connection = await oracledb.getConnection(connectionORAC);
	var lst = [];
	try
	{
		var parameterObject = {
			P_CUSTGROUP: { dir: oracledb.BIND_IN, val: Custgroup, type: oracledb.NUMBER },
			P_BRANCH_CODE: { dir: oracledb.BIND_IN, val: BranchCode, type: oracledb.STRING },
			P_AREA_ID: { dir: oracledb.BIND_IN, val: AreaId, type: oracledb.NUMBER },
			v_refCur: { dir: oracledb.BIND_OUT, type: oracledb.CURSOR }
		};
		var query = "BEGIN SYNCMANAGERUSER(:P_CUSTGROUP , :P_BRANCH_CODE , :P_AREA_ID , :v_refCur); END;";
		var result = await connection.execute(query, parameterObject);
		var row;
		var header = result.outBinds.v_refCur.metaData;
		while(row = await result.outBinds.v_refCur.getRow())
		{
			if(row == null || row == undefined)
				break;
			var objectdata = {};
			for (var j = 0; j < row.length; j++) {
				objectdata[header[j].name] = row[j];
			}
			lst.push(objectdata);
		}
		//connection.close();
		//await result.outBinds.v_refCur.close();
	}
	catch(err){
		console.log('GetManageData ' + err);
		//connection.close();
		//return null;
	}
	finally{
		await result.outBinds.v_refCur.close();
		//connection.close();
		//result.close();
		return lst;
	}
};