(function () {
    var lst = [];
    var lstchild = [];
    var oracledb = require('oracledb');
    var connectionORAC = {
        user: "ocbcrm",
        password: "123456",
        connectString: "10.96.62.10/crmpilot"
    };
    var mongoClient = require('mongodb').MongoClient;
    express = require("express");
    var url = "mongodb://127.0.0.1:27017/";
    var dbName = "crmCache";
    var CacheTableName = "SyncData";
    var collectionname = "Customer";
    var express = require('express');
    var bodyParser = require('body-parser');
    var app = express();
    // parse application/x-www-form-urlencoded
    //app.use(bodyParser.urlencoded({ extended: false }))

    // parse application/json
    app.use(bodyParser.json());
    var options = {
        useNewUrlParser: true
    }
    //Middleware
    
    async function createsyncdata() {
        var header;
        //var connection;
        try {
            var connection = await oracledb.getConnection(connectionORAC);

            var result = await connection.execute
                (
                "BEGIN SYNCDATACUSTOMER(:p_PageNum,:p_PageSize,:v_refCur); END;",
                {
                    p_PageNum: { dir: oracledb.BIND_IN, val: 1, type: oracledb.NUMBER },
                    p_PageSize: { dir: oracledb.BIND_IN, val: 100, type: oracledb.NUMBER },
                    v_refCur: { dir: oracledb.BIND_OUT, type: oracledb.CURSOR }
                }
                );

            var row;
			var header = result.outBinds.v_refCur.metaData;
            while (row = await result.outBinds.v_refCur.getRow()) {
					var objectdata = {};
                    for (var j = 0; j < row.length; j++) {
                        objectdata[header[j].name] = row[j];
                    }
					objectdata["_id"] = objectdata["CrmCustId"] != null ? objectdata["CrmCustId"] : objectdata["CifNo"];
					var resultManage = await connection.execute(
						"BEGIN SYNCMANAGERUSER(:P_CUSTGROUP , :P_BRANCH_CODE , :P_AREA_ID , :v_refCur); END;",
						{  
							P_CUSTGROUP: { dir: oracledb.BIND_IN, val: objectdata["Custgroup"], type: oracledb.NUMBER },
							P_BRANCH_CODE: { dir: oracledb.BIND_IN, val: objectdata["BranchCode"], type: oracledb.STRING },
							P_AREA_ID: { dir: oracledb.BIND_IN, val: objectdata["AreaId"], type: oracledb.NUMBER },
							v_refCur: { dir: oracledb.BIND_OUT, type: oracledb.CURSOR }
						});
					var headerchild = resultManage.outBinds.v_refCur.metaData;
					var rowchild;
					var lstchild = [];
					while (rowchild = await resultManage.outBinds.v_refCur.getRow()) {
						var objectchild = {};
						for (var i = 0; i < rowchild.length; i++) {
							objectchild[headerchild[i].name] = rowchild[i];
						}
						lstchild.push(objectchild);
					}
					objectdata["MANAGERUSER"] = lstchild;
                    lst.push(objectdata);
            }
			var mongoObject;
			Promise.all(lst.map(function(mongoObject){
				mongoClient.connect
				(
					url, 
					options, 
					function(err, db) 
					{
						if (err) 
						{
							//throw err;
						}
						var dbo = db.db(dbName);
						dbo.collection(collectionname).insertOne(mongoObject, function(err, res) 
						{
							if (err) 
							{
								//throw err;
							}
							console.log("Document inserted");
							db.close();
						});
					}
				);
			}));
			//console.log(lst);
        } catch (err) {
            console.error(err);
        } finally {
            if (connection) {
                try {
                    await connection.close();
                } catch (err) {
                    console.error(err);
                }
            }
        }
    };

    function runEachData(object) {
        return object;
    }

    app.listen(2700, function () {
        console.log('server start on port 2700');
        createsyncdata();
    });
    //app.listen(2700);

}).call(this);



