
var oracledb = require('oracledb');
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://127.0.0.1:27017/";



var dbName = "crmbackup";
var ObjectData = {
	_id: '',
	USER_ID: '', 
	USER_FULL_NAME: '', 
	USER_EMAIL: '', 
	USER_PHONE: '', 
	FUNC_GROUP: '', 
	ACCOUNT_OFFICER_ID: '',
}
var lst = [];
oracledb.getConnection(
  {
    user          : "ocbcrm",
    password      : "123456",
    connectString : "10.96.62.10/crmpilot"
  },


function(err, connection)
{
    if (err) { console.error(err); return; }
	
    // query to the database and execute procedure 
    //var query = "exec searchCustomer_node @p_CustGroup=1,@p_CustSource='PROS',@pUserId='hungnm',@p_SourceType=-1,@p_Position='QLKHOI',@p_PageNum=1,@p_PageSize=100;";
    //console.log(query);
	// connection.execute(query, function (err, result) {
        // if (err) {
            // console.log(err);
            // return;
        // }
        // console.log(result.rows);

    // });
	connection.execute(
	//test_nodejs(p_PageNum IN NUMBER, p_PageSize IN NUMBER, v_refCur OUT SYS_REFCURSOR)
		//"BEGIN test_nodejs(:p_PageNum, :p_PageSize, :v_refCur); END;",
		"BEGIN searchCustomer_node(:p_ConditionString,:p_CustGroup,:p_CustSource,:p_BranchCode,:p_OfficerId,:p_AreaId,:p_UserId,:p_SourceType,:p_Position,:p_Sort,:p_PageNum,:p_PageSize,:v_refCur); END;",
		{  // bind variables
			//p_PageNum: { dir: oracledb.BIND_IN, val: 1, type: oracledb.NUMBER },
			//p_PageSize: { dir: oracledb.BIND_IN, val: 20, type: oracledb.NUMBER },
			//v_refCur: { dir: oracledb.BIND_OUT, type: oracledb.CURSOR },
			  p_ConditionString: { dir: oracledb.BIND_IN, val: '', type: oracledb.STRING },
			  p_CustGroup: { dir: oracledb.BIND_IN, val: 1, type: oracledb.NUMBER },
			  p_CustSource: { dir: oracledb.BIND_IN, val: 'PROS', type: oracledb.STRING },
			  p_BranchCode: { dir: oracledb.BIND_IN, val: '', type: oracledb.STRING },
			  p_OfficerId: { dir: oracledb.BIND_IN, val: '', type: oracledb.STRING },
			  p_AreaId: { dir: oracledb.BIND_IN, type: oracledb.NUMBER },
			  p_UserId: { dir: oracledb.BIND_IN, val: 'hungnm', type: oracledb.STRING },
			  p_SourceType: { dir: oracledb.BIND_IN, val: -1, type: oracledb.NUMBER },
			  p_Position: { dir: oracledb.BIND_IN, val: 'QLKHOI', type: oracledb.STRING },
			  p_Sort: { dir: oracledb.BIND_IN, val: '', type: oracledb.STRING },
			  p_PageNum: { dir: oracledb.BIND_IN, val: 1, type: oracledb.NUMBER },
			  p_PageSize: { dir: oracledb.BIND_IN, val: 50, type: oracledb.NUMBER },
			  v_refCur: { dir: oracledb.BIND_OUT, type: oracledb.CURSOR }
		},
		function (err, result) {
			if (err) { 
				console.error(err); return; 
			}
			//console.log(result.outBinds.v_refCur.metaData[0].name);
			//var collectionname = "CUSTOMERS";
			var collectionname = "SearchCustomerUser";
			var pagesize = 100;
			var total = 0;
			fetchRowsFromRS(connection, collectionname, result.outBinds.v_refCur.metaData, result.outBinds.v_refCur, pagesize);
		}
	);
    //connection.close();
});
function fetchRowsFromRS(connection, collectionname, header, resultSet, pagesize)
{
	resultSet.getRows( 
		// get numRows rows
		pagesize,
		function (err, rows)
		{
		  if (err) {
           console.log(err);// close the result set and release the connection
		  } else if (rows.length == 0) {  // no rows, or no more rows
            //console.log('rows length = 0');// close the result set and release the connection
		  } else if (rows.length > 0) {
			//console.log('rows length: ' + rows.length);
			MongoClient.connect(url, function(err, db) {
				if (err) throw err;
				// db pointing to newdb
				//console.log("Switched to "+db.databaseName+" database");
				var dbo = db.db(dbName);
				// document to be inserted
				lst = [];
				for(var i = 0; i <rows.length;i++)
				{
					var objectdata = {};
					
					for(var j = 0; j < rows[i].length;j++)
					{
						if(j == 0)
						{
							objectdata["_id"] = rows[i][j];
						}
						objectdata[header[j].name] = rows[i][j];
					}
					lst.push(objectdata);
				}
				//console.log(lst);
				// insert document to 'users' collection using insertOne
				dbo.collection(collectionname).insertMany(lst, function(err, res) {
					 if (err) throw err;
					 //console.log("Document inserted");
					 db.close();
				 });
				 
			});
			fetchRowsFromRS(connection, collectionname, header, resultSet, pagesize);
		  }
    });
}