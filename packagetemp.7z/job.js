(function () {
	var lst = [];
	var oracledb = require('oracledb');
	var connectionORAC = {
		user          : "ocbcrm",
		password      : "123456",
		connectString : "10.96.62.10/crmpilot"
	  };
    var mongoClient = require('mongodb').MongoClient;
    express = require("express");
	var url = "mongodb://127.0.0.1:27017/";
	var dbName = "crmCache";
	var CacheTableName = "CacheData";
	var express = require('express');
	var bodyParser = require('body-parser');
	var app = express();
	app.use(bodyParser.json());
	var isjobdone = true;
	var options = {
		useNewUrlParser: true
	}
	//Middleware
	function binddata()
	{
		if(!isjobdone)
			return;
		isjobdone = false;
		console.log("I was executed");
		isjobdone = true;
	}
	app.listen(4000, function(){
		console.log('server start on port 3000');
		setInterval(binddata, 5000);
	});
    //app.listen(80);

}).call(this);



