(function () {
	var lst = [];
	var lstchild = [];
	var oracledb = require('oracledb');
	var connectionORAC = {
		user          : "ocbcrm",
		password      : "123456",
		connectString : "10.96.62.10/crmpilot"
	  };
    var mongoClient = require('mongodb').MongoClient;
    express = require("express");
	var url = "mongodb://127.0.0.1:27017/";
	var dbName = "crmCache";
	var CacheTableName = "SyncData";
	var express = require('express');
	var bodyParser = require('body-parser');
	var app = express();
	// parse application/x-www-form-urlencoded
	//app.use(bodyParser.urlencoded({ extended: false }))

	// parse application/json
	app.use(bodyParser.json());
	var options = {
		useNewUrlParser: true
	}
	//Middleware
	function fetchRowsFromRS(connection, collectionname, header, resultSet, pagesize)
	{
		resultSet.getRows
		( 
			pagesize,
			function (err, rows)
			{
				if (err) 
				{
					console.log(err);// close the result set and release the connection
					return;
				} 
				else if (rows.length == 0) 
				{  
					// no rows, or no more rows
				} 
				else if (rows.length > 0) 
				{
						//var dbo = db.db(dbName);
						// document to be inserted
						lst = [];
						// for(var i = 0; i < rows.length; i++)
						// {
							// console.log(rows[i]);
						// }
						lst = [];
						var objectdata = {};
						for(var i = 0; i < rows.length; i++)
						{
							objectdata = {};
							//console.log(objectdata);
							for(var j = 0; j < rows[i].length;j++)
							{
								objectdata[header[j].name] = rows[i][j];
							}
							objectdata["MANAGERUSER"] = [];
							//console.log(objectdata);
							oracledb.getConnection(
								connectionORAC,
								function(err, connection)
								{
									if (err) { console.error(err); return; }
									//console.log("SELECT QUERYSTRING FROM CRM_QUERYTABLE WHERE ID = '" + idquery + "'");
									//oracledb.fetchAsString = [ oracledb.CLOB ];
									connection.execute(
										"BEGIN SYNCMANAGERUSER(:P_CUSTGROUP , :P_BRANCH_CODE , :P_AREA_ID , :v_refCur); END;",
										{  
											P_CUSTGROUP: { dir: oracledb.BIND_IN, val: objectdata["Custgroup"], type: oracledb.NUMBER },
											P_BRANCH_CODE: { dir: oracledb.BIND_IN, val: objectdata["BranchCode"], type: oracledb.STRING },
											P_AREA_ID: { dir: oracledb.BIND_IN, val: objectdata["AreaId"], type: oracledb.NUMBER },
											v_refCur: { dir: oracledb.BIND_OUT, type: oracledb.CURSOR }
										},
										function (err, resultchild) {
											if (err) { 
												console.log(err);
											}
											//console.log(resultchild);
											fetchMiniList(objectdata, connection, collectionname, resultchild.outBinds.v_refCur.metaData, resultchild.outBinds.v_refCur, 100);
											//console.log(objectdata);
											objectdata["_id"] = objectdata["CrmCustId"] != null ? objectdata["CrmCustId"] : objectdata["CifNo"];
											//console.log(objectdata);
											mongoClient.connect
											(
												url, 
												options, 
												function(err, db) {
													if (err) 
													{
														//throw err;
													}
													var dbo = db.db(dbName);
													dbo.collection(collectionname).insertOne(objectdata, function(err, res) {
														if (err) 
														{
															//throw err;
														}
														//console.log("Document inserted");
														db.close();
													});
												}
											);
										}
									);
									
								}
							);

						}
					fetchRowsFromRS(connection, collectionname, header, resultSet, pagesize);
				}
			}
		);
	}
	
	function fetchMiniList(objectdata, connection, collectionname, header, resultSet, pagesize)
	{
		//console.log(objectdata);
		resultSet.getRows
		( 
			pagesize,
			function (err, rows)
			{
				if (err) 
				{
					console.log(err);// close the result set and release the connection
				} 
				else if (rows.length == 0) 
				{  
					// no rows, or no more rows
				} 
				else if (rows.length > 0) 
				{
					for(var i = 0; i <rows.length;i++)
					{
						var objectchilddata = {};
						
						for(var j = 0; j < rows[i].length;j++)
						{
							objectchilddata[header[j].name] = rows[i][j];
						}
						objectdata["MANAGERUSER"].push(objectchilddata);
					}
					//console.log(objectdata);
					//fetchMiniList(connection, collectionname, header, resultSet, 100);
				}
				
			}
		);
	}
	
	function createsyncdata(){
		oracledb.getConnection(
			connectionORAC,
			function(err, connection)
			{
				if (err) { console.error(err); return; }
				connection.execute(
					"BEGIN SYNCDATACUSTOMER(:p_PageNum,:p_PageSize,:v_refCur); END;",
					{  
						p_PageNum: { dir: oracledb.BIND_IN, val: 1, type: oracledb.NUMBER },
						p_PageSize: { dir: oracledb.BIND_IN, val: 2, type: oracledb.NUMBER },
						v_refCur: { dir: oracledb.BIND_OUT, type: oracledb.CURSOR }
					},
					function (err, result) {
						if (err) { 
							console.log(err);
							return;
						}
						var collectionname = "Customer";
						
						fetchRowsFromRS(connection, collectionname, result.outBinds.v_refCur.metaData, result.outBinds.v_refCur, 100);
					}
				);
				
			}
		);
	};
	
	app.listen(2700, function(){
		console.log('server start on port 2700');
		createsyncdata();
	});
    //app.listen(2700);

}).call(this);



