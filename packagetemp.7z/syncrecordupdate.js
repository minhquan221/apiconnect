var mongoData = require("./mongodata").mongoData;
var oracleConnect = require("./oracle").oracleConnect;
var logFile = require("./readFile").FileStream;
var SyncChangeData = (exports.SyncChangeData = {});
var isSync = false;
var currentrunId = 0;
var logFilelastIDSync = "./idsync.txt";

SyncChangeData.Sync = async function(){
	try
	{
		isSync = true;
		var lastId = await oracleConnect.GetLastID();
		console.log(lastId);
		if(currentrunId == 0)
			currentrunId = await logFile.readFileAsync(logFilelastIDSync);
		if(parseInt(currentrunId) < parseInt(lastId))
		{
			isSync = true;
			await oracleConnect.GetSyncCust(currentrunId, lastId);
			currentrunId = lastId;
			
			console.log('sync data complete to ID: ' + currentrunId);
			//var logResult = await logFile.WriteFileAsync(logFilelastIDSync, currentrunId);
		}
		else
		{
			console.log('no new data');
		}
	}
	catch(err){
		console.log('SyncChangeData.Sync ' + err);
	}
	finally{
		isSync = false;
	}
	
};

SyncChangeData.Interval = async function(){
	setInterval(async function(){
		if(!isSync)
		{
			console.log('begin sync change data');
			await SyncChangeData.Sync();
			console.log('end sync change data');
		}
	}, 3000);
}

SyncChangeData.SyncData = async function(){
	try
	{
		await SyncChangeData.Interval();
	}
	catch(err){
		console.log('SyncChangeData.SyncData ' + err);
	}
	finally{
		
	}
}
