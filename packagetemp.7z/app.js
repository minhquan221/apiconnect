var express = require('express');
//var bodyParser = require('body-parser');
var app = express();
var router = require("./router");
//var SyncData = require("./syncdata").SyncData;

app.use("/", router);


app.listen(3000, function() {
  console.log("Server NodeJS Listening on port 3000");
  //SyncData.Synchornize();
});