var express = require('express');
var bodyParser = require('body-parser');
var app = express();
var bodyParser = require('body-parser');
var express = require("express");
var router = new express.Router();
//var logger = require("./logger").Logger;
var mongoData = require("./mongodata").mongoData;
var Signature = require("./DynamicSign").DynamicSign;
var CacheTableName = "CacheData";
var SyncTableName = "Customer";
// router.use(function timeLog(req, res, next) {
  // // this is an example of how you would call our new logging system to log an info message
  // logger.info("Test Message");
  // next();
// });
router.use(bodyParser.json());
router.post("/createdatacache", async function(request, res){
	var objectMongo = 
	{
		_id: request.body.keycache,
		ExpirateDate: request.body.data.ExpirateDate,
		TotalRows: request.body.data.TotalRows,
		ListObject: request.body.data.ListObject,
	}
	var resultdata = await mongoData.WriteCache(objectMongo, CacheTableName);
	if(resultdata.error == 0)
	{
		res.send('1');
	}
	else
	{
		res.send(resultdata.msg);
	}
});

router.post("/getcachesearch", async function(request, res){
	var keycache = request.body.keycache;
	var resultdata = await mongoData.ReadCache(keycache, CacheTableName);
	if(resultdata.error == 0)
	{
		res.send(resultdata.data);
	}
	else
	{
		res.send(resultdata.msg);
	}
});

router.post("/signaturedata", async function(request, res){
	var privatekey = request.body.privatekey;
	var data = request.body.data;
	var resultdata = await Signature.WriteSignature(privatekey, data);
	if(resultdata.error == 0)
	{
		res.send(resultdata.data);
	}
	else
	{
		res.send(resultdata.msg);
	}
});

router.post("/cleardatacache", async function(request, res){
	var resultdata = await mongoData.ClearCache();
	if(resultdata.error == 0)
	{
		res.send("1");
	}
	else
	{
		res.send("0");
	}
});

router.post("/querymongo", async function(request, res){
	console.log(request.body);
	var p_ConditionString = request.body[0];
	var p_CustGroup = request.body[1];
	var p_CustSource = request.body[2]; 
	var p_BranchCode = request.body[3];
	var p_OfficerId = request.body[4];
	var p_AreaId = request.body[5]; 
	var p_UserId = request.body[6];
	var p_SourceType = request.body[7];
	var p_Position = request.body[8];
	var p_Sort = request.body[9];
	var p_PageNum = request.body[10];
	var p_PageSize = request.body[11]; 
	var collection = p_CustSource == 'PROS' ? 'CustomerPros' : 'Customer';
	console.log(collection);
	var query = {};
	
	var objectCondition = {};
	if(p_ConditionString != '')
	{
		objectCondition = JSON.parse(p_ConditionString);
	}
	var query = await mongoData.BuildQuery(objectCondition);
	
	if(p_CustGroup != '' && p_CustGroup != null && p_CustGroup != -1)
		query["Custgroup"] = p_CustGroup;
	if(p_BranchCode != '' && p_BranchCode != null)
		query["BranchCode"] = p_BranchCode;
	if(p_OfficerId != '' && p_OfficerId != null)
		query["AccountOfficer"] = p_OfficerId;
	if(p_AreaId != '' && p_AreaId != null && p_AreaId != -1)
		query["AreaId"] = p_AreaId;
	if(p_SourceType != '' && p_SourceType != null && p_SourceType != -1)
		query["SourceType"] = p_SourceType;
	if(p_Position != '')
		query["MANAGERUSER.POSITION_ID"] = p_Position;
	if(p_UserId != '')
		query["MANAGERUSER.USER_ID"] = p_UserId;
	var resultdata = await mongoData.QueryData(query, collection, p_PageNum, p_PageSize);
	
	res.send(resultdata);

});

module.exports = router;