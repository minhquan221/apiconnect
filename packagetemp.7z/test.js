var express = require('express');
//var bodyParser = require('body-parser');
var app = express();
var router = require("./router");
var readfile = require("./readFile").ReadFile;
var fs = require("fs");
var mongoData = require("./mongodata").mongoData;
var oracleConnect = require("./testoracle").oracleConnect;
var StoreTableCustomer = "SYNCDATACUSTOMER";
var StoreTableCustomerPROS = "SYNCDATACUSTOMER2";
var Collection1 = "Customer";
var Collection2 = "CustomerPros";

app.use("/", router);
Test = async function(){
	try
	{
		//var res = await oracleConnect.GetBigDataSync({ storename: StoreTableCustomer, collection: Collection1 }, 1, 100000);
		//console.log('get data done');
		//readfile.Read('c:\\packagetemp\\abcde.txt');
		readfile.Read('c:\\packagetemp\\abcde.txt');
		//readfile.readFile('c:\\packagetemp\\abcde.txt');
	}
	catch(err){
		console.log('Test ' + err);
	}
	finally{
		
	}
}

app.listen(2900, function() {
  console.log("Server Test NodeJS Listening on port 2800");
  Test();
});