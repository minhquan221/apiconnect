var jose = require('node-jose');
var jws = require('jws');
var crypto = require('crypto');
//Khai bao certname
//var publicKey='SEATECH_SCERT';

/*Hàm Dynamic thực hiện ký như sau:
	Nội dung ký được truyền vào phần body,
	Private key được truyền lên Header với biến là X-Private-Key, nội dung là đoạn base64 của file Private key
	Ký theo RS256
	Phương thức ký theo chuẩn JWS: <header>.<payload>.<signature>
	Với <header> là đoạn base64 chứa thuật toán ký.
	<Payload> là đoạn base64 của nội dung ký (chuỗi json trong phần body).
	<signature> là đoạn ký theo private key của chuỗi <header>.<payload>
*/
var DynamicSign = (exports.DynamicSign = {});
DynamicSign.WriteSignature = async function(privateKeyText, jsondata) {
	console.log(privateKeyText);
	//console.log(jsondata);
	var returnObject = { error: 0, msg: '', data: null };
	var key = new Buffer.from(privateKeyText,'base64');
	json = JSON.stringify(jsondata);
	var signature = await jws.sign({
		header: { alg: 'RS256' },
		payload: jsondata,
		privateKey: privateKeyText,
	  });
	  console.log(signature);
	return returnObject;
};