(function () {
	var lst = [];
	var oracledb = require('oracledb');
	var connectionORAC = {
		user          : "ocbcrm",
		password      : "123456",
		connectString : "10.96.62.10/crmpilot"
	  };
    var mongoClient = require('mongodb').MongoClient;
    express = require("express");
	var url = "mongodb://127.0.0.1:27017/";
	var dbName = "crmCache";
	var CacheTableName = "CacheData";
	var express = require('express');
	var bodyParser = require('body-parser');
	var app = express();
	// parse application/x-www-form-urlencoded
	//app.use(bodyParser.urlencoded({ extended: false }))

	// parse application/json
	app.use(bodyParser.json());
	var options = {
		useNewUrlParser: true
	}
	//Middleware
	function fetchRowsFromRS(connection, collectionname, header, resultSet, pagesize)
	{
		resultSet.getRows( 
			pagesize,
			function (err, rows)
			{
			  if (err) {
			   console.log(err);// close the result set and release the connection
			  } else if (rows.length == 0) {  // no rows, or no more rows
			  } else if (rows.length > 0) {
				mongoClient.connect(url, options, function(err, db) {
					if (err) 
					{
						//throw err;
					}
					var dbo = db.db(dbName);
					// document to be inserted
					lst = [];
					for(var i = 0; i <rows.length;i++)
					{
						var objectdata = {};
						
						for(var j = 0; j < rows[i].length;j++)
						{
							if(j == 0)
							{
								objectdata["_id"] = rows[i][j];
							}
							objectdata[header[j].name] = rows[i][j];
						}
						lst.push(objectdata);
					}
					dbo.collection(collectionname).insertMany(lst, function(err, res) {
						 if (err) 
						 {
							 //throw err;
						 }
						 console.log("Document inserted");
						 db.close();
					 });
					 
				});
				fetchRowsFromRS(connection, collectionname, header, resultSet, pagesize);
			  }
		});
	}
	app.post("/createcache", function(request, response){
		var keycache = request.body.keycache;
		var idquery = request.body.idquery;
		mongoClient.connect(url, options, function(err, db) {
		  if (err) 
		  {
			  //throw err;
		  }
		  var dbo = db.db(dbName);
		  dbo.collection(keycache).drop(function(err, delOK) {
			if (err) 
			{
				console.log(err);
				//throw err;
			}
			if (delOK) 
			{
				console.log("Collection deleted");
			}
			db.close();
		  });
		});
		oracledb.getConnection(
			connectionORAC,
			function(err, connection)
			{
				if (err) { console.error(err); return; }
				//console.log("SELECT QUERYSTRING FROM CRM_QUERYTABLE WHERE ID = '" + idquery + "'");
				//oracledb.fetchAsString = [ oracledb.CLOB ];
				connection.execute(
					"BEGIN run_CacheQuery(:p_id,:v_refCur); END;",
					{  
						p_id: { dir: oracledb.BIND_IN, val: idquery, type: oracledb.STRING },
						v_refCur: { dir: oracledb.BIND_OUT, type: oracledb.CURSOR }
					},
					function (err, result) {
						if (err) { 
							console.log('createcache id ' + idquery + ' fail ' + err);
							return; 
						}
						var collectionname = keycache;
						console.log('createcache id ' + idquery + ' with keycache ' + keycache + ' success');
						fetchRowsFromRS(connection, collectionname, result.outBinds.v_refCur.metaData, result.outBinds.v_refCur, 100);
					}
				);
				
			}
		);
	});
	app.post("/getobject", function(request, response){
		//var p_ConditionString = request.body.p_ConditionString;
		var p_ConditionString = JSON.parse(request.body[0]);
		console.log(condition[0].ConditionName);
		// p_ConditionString, p_CustGroup, 
		// p_CustSource, p_BranchCode, 
		// p_OfficerId, p_AreaId, 
		// p_UserId, SourceType, 
		// LoggedUser.CurrentRole.PositionId, str_sort, 
		// p_PageNum, p_PageSize, totalSize
		//console.log(objectquery);
		mongoClient.connect(url, options, function(err, db) {
			if (err) 
			{
				//throw err;
			}
			//var collectionname = keycache;
			var dbo = db.db(dbName);
			var Customer = dbo.collection("Customer");
			Customer.find({
				"MANAGERUSER.POSITION_ID" : "QLKHOI", "MANAGERUSER.USER_ID" : "hungnm" }
			).toArray(function(err, res){
				if (err) 
				{
					console.log('getcachesearch fail ' + err);
					//throw err;
				}
				//nếu thành công
				//console.log(res);
				db.close();
				response.writeHead(200, {
					'Content-Type': 'text/plain',
					'Access-Control-Allow-Origin' : '*',
					'Access-Control-Allow-Methods': 'GET,PUT,POST,DELETE'
				});
				response.end(JSON.stringify(res));
			});
			db.close();
		});
	});
	app.post("/createdatacache", function(request, response){
		var objectMongo = 
		{
			_id: request.body.keycache,
			ExpirateDate: request.body.data.ExpirateDate,
			TotalRows: request.body.data.TotalRows,
			ListObject: request.body.data.ListObject,
		}
		for(var i = 0; i < lst.length; i++)
		{
			objectMongo.ListObject.push(lst[i]);
		}
		mongoClient.connect(url, options, function(err, db) {
		  if (err) 
		  {
			  //throw err;
		  }
		  var dbo = db.db(dbName);
		  dbo.collection(CacheTableName).deleteOne({
				"_id": objectMongo._id
			}, function(err, results) {
				if(err)
				{
					console.log(err);
					//throw err;
					response.writeHead(200, {
						'Content-Type': 'text/plain',
						'Access-Control-Allow-Origin' : '*',
						'Access-Control-Allow-Methods': 'GET,PUT,POST,DELETE'
					});
					response.end(JSON.stringify("0"));
				}
				dbo.collection(CacheTableName).insertOne(objectMongo, function(err, res) {
					if (err) 
					{
						console.log(err);
						//throw err;
						response.writeHead(200, {
							'Content-Type': 'text/plain',
							'Access-Control-Allow-Origin' : '*',
							'Access-Control-Allow-Methods': 'GET,PUT,POST,DELETE'
						});
						response.end(JSON.stringify("0"));
					}
					console.log("Document inserted");
					response.writeHead(200, {
						'Content-Type': 'text/plain',
						'Access-Control-Allow-Origin' : '*',
						'Access-Control-Allow-Methods': 'GET,PUT,POST,DELETE'
					});
					response.end(JSON.stringify("1"));
					db.close();
				});
			});
		  
		});
	});
	app.post("/getcachesearch", function (request, response) {
		var keycache = request.body.keycache;
        mongoClient.connect(url, options, function(err, db) {
			if (err) 
			{
				//throw err;
			}
			//var collectionname = keycache;
			var dbo = db.db(dbName);
			var Customer = dbo.collection(CacheTableName);
			Customer.find({_id: keycache}).toArray(function (err, res) {
				//nếu có lỗi
				if (err) 
				{
					console.log('getcachesearch fail ' + err);
					//throw err;
				}
				//nếu thành công
				console.log('getcachesearch ' + keycache + ' success');
				db.close();
				response.writeHead(200, {
					'Content-Type': 'text/plain',
					'Access-Control-Allow-Origin' : '*',
					'Access-Control-Allow-Methods': 'GET,PUT,POST,DELETE'
				});
				response.end(JSON.stringify(res));
			});
			db.close();
		});
    });
	app.listen(3000, function(){
		console.log('server start on port 3000');
	});
    //app.listen(80);

}).call(this);



