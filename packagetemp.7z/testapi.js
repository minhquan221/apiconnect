var request = require("request");

var options = 
{ 
	method: 'POST',
	url: 'https://api-sit.ocb.com.vn/ocbsit/developer/ocb-sit-oauth/oauth2/token',
	headers: 
	{ 
		accept: 'application/json',
		'content-type': 'application/json',
		//authorization: 'Bearer REPLACE_BEARER_TOKEN',
		//'x-ibm-client-secret': 'Client secret',
		//'x-ibm-client-id': 'Client ID' 
	},
	body: 
	{ 
		grant_type: 'password',
		username: 'quanocb',
		password: 'Qwerty!23456',
		client_id: 'dbf2c69076cbd5c1bd314baac3512c5c',
		client_secret: '7d9a8c93af648d49db1aceac65c9a44c',
		scope: 'OCBSIT'
	},
	json: true 
};
process.env["NODE_TLS_REJECT_UNAUTHORIZED"] = 0;
request(options, function (error, response, body) {
  if (error) return console.error('Failed: %s', error);

  console.log('Success: ', body);
});