var fs = require("fs");


var FileStream = (exports.FileStream = {});

FileStream.readFileAsync = async function(filename) {
    return new Promise
	(
		function(resolve, reject) {
			fs.readFile(
				filename, 
				function(err, data)
				{
					if (err) 
						resolve('0');
					else 
						resolve(data);
				}
			);
		}
	);
};
FileStream.WriteFileAsync = async function(filename, data){
	return new Promise
	(
		function(resolve, reject) {
			fs.writeFile(
				filename, 
				data,
				function(err)
				{
					if (err) 
						resolve(0);
					else 
						resolve(1);
				}
			);
		}
	);
};
