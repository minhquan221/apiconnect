<?php

/********************************************************* {COPYRIGHT-TOP} ***
 * Licensed Materials - Property of IBM
 * 5725-L30, 5725-Z22
 *
 * (C) Copyright IBM Corporation 2018, 2019
 *
 * All Rights Reserved.
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 ********************************************************** {COPYRIGHT-END} **/

namespace Drupal\customproduct\Controller;

use Drupal\apic_api\Api;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Url;
use Drupal\file\Entity\File;
use Drupal\node\Entity\Node;
use Drupal\node\NodeInterface;
use Drupal\product\Product;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\RequestStack;

/**
 * Controller routines for product routes.
 */
class CustomProductController extends ControllerBase {

  /**
   * Request stack.
   *
   * @var RequestStack
   */
  public $request;

  /**
   * Class constructor.
   *
   * @param RequestStack $request
   *   Request stack.
   */
  public function __construct(RequestStack $request) {
    $this->request = $request;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    // Instantiates this form class.
    return new static(// Load the service required to construct this class.
      $container->get('request_stack'));
  }

  public function ExamplePage(NodeInterface $prodNode, NodeInterface $apiNode) {
    if ($prodNode !== NULL && $apiNode !== NULL && $prodNode->id() && $apiNode->id()) {
      ibm_apim_entry_trace(__CLASS__ . '::' . __FUNCTION__, [
        'prodNode' => $prodNode->id(),
        'apiNode' => $apiNode->id(),
      ]);
    }
    else {
      ibm_apim_entry_trace(__CLASS__ . '::' . __FUNCTION__, NULL);
    }
    $found = FALSE;
    $config = \Drupal::config('ibm_apim.settings');
    $ibmApimShowVersions = (boolean) $config->get('show_versions');
    if ($ibmApimShowVersions === NULL) {
      $ibmApimShowVersions = TRUE;
    }
    $ibmApimShowPlaceholderImages = (boolean) $config->get('show_placeholder_images');
    if ($ibmApimShowPlaceholderImages === NULL) {
      $ibmApimShowPlaceholderImages = TRUE;
    }
    $api = '';
    $product = '';

    if ($prodNode !== NULL && $prodNode->bundle() === 'product') {
      if ($apiNode !== NULL && $apiNode->bundle() === 'api') {
        // check this product actually includes the specified API
        $prodRefs = [];
        foreach ($prodNode->product_apis->getValue() as $arrayValue) {
          $prodRefs[] = unserialize($arrayValue['value'], ['allowed_classes' => FALSE]);
        }
        foreach ($prodRefs as $prodRef) {
          if ($prodRef['name'] === $apiNode->apic_ref->value) {
            $found = TRUE;
            $product = [
              'nid' => $prodNode->id(),
              'id' => $prodNode->product_id->value,
              'title' => $prodNode->getTitle(),
              'version' => $prodNode->apic_version->value,
              'pathalias' => $prodNode->apic_pathalias->value,
            ];
          }
        }

        $fid = $apiNode->apic_image->getValue();
        $apiImageUrl = NULL;
        if (isset($fid[0]['target_id'])) {
          $file = File::load($fid[0]['target_id']);
          if (isset($file)) {
            $apiImageUrl = $file->toUrl()->toUriString();
          }
        }
        elseif ($ibmApimShowPlaceholderImages === TRUE) {
          $rawImage = Api::getRandomImageName($apiNode->getTitle());
          $apiImageUrl = base_path() . drupal_get_path('module', 'apic_api') . '/images/' . $rawImage;
        }

        $api = [
          'nid' => $apiNode->id(),
          'id' => $apiNode->api_id->value,
          'title' => $apiNode->getTitle(),
          'version' => $apiNode->apic_version->value,
          'pathalias' => $apiNode->apic_pathalias->value,
          'image_url' => $apiImageUrl,
        ];

        if (!$found) {
          \Drupal::logger('product')->error('productApi: product does not contain the specified API.', []);
          drupal_set_message(t('The specified arguments were not correct.'), 'warning');
        }
      }
      else {
        \Drupal::logger('product')->error('productApi: not a valid API.', []);
        drupal_set_message(t('The specified arguments were not correct.'), 'warning');
      }
    }
    else {
      \Drupal::logger('product')->error('productApi: not a valid product.', []);
      drupal_set_message(t('The specified arguments were not correct.'), 'warning');
    }

    ibm_apim_exit_trace(__CLASS__ . '::' . __FUNCTION__, $found);
    if ($found) {
      $attached = ['library' => []];
      $attached['library'][] = 'product/basic';
      $moduleHandler = \Drupal::service('module_handler');
      if ($moduleHandler->moduleExists('votingapi_widgets')) {
        $attached['library'][] = 'votingapi_widgets/fivestar';
      }
      $theme = 'customproduct_theme';
      //drupal_set_message(t($product), 'warning');
      return [
        '#theme' => $theme,
        '#api' => $api,
        '#product' => $product,
        '#attached' => $attached,
        '#showPlaceholders' => $ibmApimShowPlaceholderImages,
        '#showVersions' => $ibmApimShowVersions,
      ];
    }
    else {
      \Drupal::logger('product')
        ->error('productApi: api %api is not in product %product.', [
          '%api' => $apiNode->id(),
          '%product' => $prodNode->id(),
        ]);
      drupal_set_message(t('The specified arguments were not correct.'), 'warning');
      $url = Url::fromRoute('<front>')->toString();
      return new RedirectResponse($url);
    }
  }
}