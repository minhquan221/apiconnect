<?php

namespace Drupal\test\Controller;

use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\AppendCommand;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Url;
use Drupal\test\Utility\DescriptionTemplateTrait;
use Symfony\Component\HttpFoundation\Response;

/**
 * Controller routines for AJAX example routes.
 */
class TestController extends ControllerBase {

  use DescriptionTemplateTrait;

  /**
   * {@inheritdoc}
   */
  protected function getModuleName() {
    return 'Test Dev Example';
  }

  /**
   * Demonstrates a clickable AJAX-enabled link using the 'use-ajax' class.
   *
   * Because of the 'use-ajax' class applied here, the link submission is done
   * without a page refresh.
   *
   * When using the AJAX framework outside the context of a form or a renderable
   * array of type 'link', you have to include ajax.js explicitly.
   *
   * @return array
   *   Form API array.
   *
   * @ingroup ajax_example
   */
	public function renderForm(){
		$build['ajax_link'] = 
		[
			'#type' => 'details',
			'#title' => $this->t('This is the AJAX link'),
			'#open' => TRUE,
		];
		$build['ajax_link']['inputtext'] = 
		[
			'#type' => 'textfield',
			'#title' => $this->t('Input text'),
			'#placeholder' => $this->('Input something in this')
		];
		$build['ajax_link']['link'] = 
		[
			'#type' => 'link',
			'#title' => $this->t('Click me'),
			'#attached' => ['library' => ['core/drupal.ajax']],
			'#attributes' => ['class' => ['use-ajax']],
			'#url' => Url::fromRoute('test.ajaxFunction1'),
		];
		// We provide a DIV that AJAX can append some text into.
		$build['ajax_link']['destination'] = 
		[
			'#type' => 'container',
			'#attributes' => ['id' => ['test-destination-div']],
		];
		return $build;
	}
	public function ajaxFunction1(){
		$output = $this->t("This is some content delivered via AJAX");
		$response = new AjaxResponse();
		$response->addCommand(new AppendCommand('#test-destination-div', $output));

		// See ajax_example_advanced.inc for more details on the available
		// commands and how to use them.
		// $page = array('#type' => 'ajax', '#commands' => $commands);
		// ajax_deliver($response);
		return $response;
		
	}
}
