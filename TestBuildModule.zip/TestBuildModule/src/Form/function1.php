<?php

namespace Drupal\test\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * A relatively simple AJAX demonstration form.
 */
class function1 extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'frm1';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
	$form['inputthis'] = 
	[
		'#title' => $this->t("Input something"),
		'#type' => 'textfield',
		'#placeholder' => 'Input anything you want',
		'#ajax' => [
			'callback' => '::ShowDataInput',
			'wrapper' => 'replace_contain',
		],
	];
	$form['replace_contain'] = 
	[
		'#type' => 'container',
		'#attributes' => 
		[
			'id' => 'replace_contain',
			'style' => 'border: 1px solid red;'
		],
    ];
	$form['replace_contain']['replace_textfield'] = [
      '#type' => 'textfield',
      '#title' => $this->t("Value input:"),
    ];
	
	
    
    // The 'replace-textfield-container' container will be replaced whenever
    // 'changethis' is updated.
    // $form['replace_textfield_container'] = [
      // '#type' => 'container',
      // '#attributes' => ['id' => 'replace-textfield-container'],
    // ];
    // $form['replace_textfield_container']['replace_textfield'] = [
      // '#type' => 'textfield',
      // '#title' => $this->t("Why"),
    // ];

    // An AJAX request calls the form builder function for every change.
    // We can change how we build the form based on $form_state.
    $value = $form_state->getValue('inputthis');
    // The getValue() method returns NULL by default if the form element does
    // not exist. It won't exist yet if we're building it for the first time.
    if ($value !== NULL) {
      $form['replace_contain']['replace_textfield']['#description'] =
        $this->t("You typed '@value'", ['@value' => $value]);
    }
    return $form;
  }

  public function promptCallback($form, FormStateInterface $form_state) {
    return $form['replace_contain'];
  }

}
