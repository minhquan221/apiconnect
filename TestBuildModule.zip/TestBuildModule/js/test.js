/**
 * @file
 * JavaScript for ajax_example.
 */

(function ($) {
  Drupal.behaviors.HelloWord = {
    attach: function () {
      alert('Hello my custom module');
    }
  };

})(jQuery);
