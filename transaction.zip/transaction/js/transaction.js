(function ($) {
    function resetTable(idTable) {
        $('#' + idTable).html("<thead></thead> <tbody></tbody>");
    }

    function buildHeader(obj, idTable) {
        var tr = '<tr>';
        for (var i = 0; i < Object.keys(obj).length; i++) {
            tr += '<th style="border: 1px solid black;">' + Object.keys(obj)[i] + '</th>';
        }

        tr += '</tr>';
        $('#' + idTable + ' thead').append(tr);
    }

    function buildBody(obj, idTable) {
        var tr = buildStringBody(obj, 0);
        $('#' + idTable + ' tbody').append(tr);
    }

    function buildStringBody(obj, subBD) {
        if (obj != null) {
            if (subBD > 0) {
                var tr = '<ul>';
                for (var i = 0; i < Object.keys(obj).length; i++) {
                    if (typeof obj[Object.keys(obj)[i]] === 'object') {
                        tr += buildStringBody(obj[Object.keys(obj)[i]], 1);
                    } else {
                        if (isNaN(obj[Object.keys(obj)[i]]) && obj[Object.keys(obj)[i]].indexOf('Date(') >= 0) {
                            var ts = obj[Object.keys(obj)[i]].replace('/Date(', '').replace(')/', '');
                            var date = new Date(Number(ts));
                            tr += '<li>' + Object.keys(obj)[i] + ": " + date.getDay() + "-" + date.getMonth() + "-" + date.getFullYear() + '</li>';
                        } else {
                            tr += '<li>' + Object.keys(obj)[i] + ": " + obj[Object.keys(obj)[i]] + '</li>';
                        }
                    }
                }
                tr += '</ul>';
                return tr;
            } else {
                var tr = '<tr>';
                for (var i = 0; i < Object.keys(obj).length; i++) {
                    if (typeof obj[Object.keys(obj)[i]] === 'object') {
                        tr += '<td style="border: 1px solid black;">' + buildStringBody(obj[Object.keys(obj)[i]], 1) + '</td>';
                    } else {
                        if (isNaN(obj[Object.keys(obj)[i]]) && obj[Object.keys(obj)[i]].indexOf('Date(') >= 0) {
                            var ts = obj[Object.keys(obj)[i]].replace('/Date(', '').replace(')/', '');
                            var date = new Date(Number(ts));
                            tr += '<td style="border: 1px solid black;">' + date.getDay() + "-" + date.getMonth() + "-" + date.getFullYear() + '</td>';
                        } else {
                            tr += '<td style="border: 1px solid black;">' + obj[Object.keys(obj)[i]] + '</td>';
                        }
                    }
                }
                tr += '</tr>';
                return tr;
            }
        }
    }

    function BuildTable(idElement, data, className) {
        var $html = '';
        $html += '<div class="row"><div class="col-md-12">';
        $html += '<table id="' + idElement + '" class="' + className + '">';
        $html += '</thead></thead>';
        $html += '</tbody></tbody>';
        $html += '</table>';
        $html += '</div></div>';
        if (data != null && data != '') {
            buildHeader(data);
            buildBody(data);
        }
    };

    function BuildInput(idElement, type, className, valuedata) {
        var $html = '';

        $html += '<div class="col-md-6"><input type="' + type + '" id="' + idElement + '" name="' + idElement + '" class="' + className + '" /></div>';

        return $html;
    }

    function BuilFormFilter() {
        var $html = '';
        $html += '<div class="row"><div class="col-md-12"><div class="form-group row">';
        $html += BuildInput('appId', 'textbox', 'form-control', '');
        $html += BuildInput('fromDate', 'textbox', 'form-control datepicker', '');
        $html += BuildInput('toDate', 'textbox', 'form-control datepicker', '');
        $html += '</div></div></div>';
        $html += '<div class="row"><div class="col-md-12"><div class="form-group row">';
        $html += BuildInput('btnClick', 'button', 'btn-primary', '');
        $html += '</div></div></div>';
        $html += BuildTable('tbData', null);
        return $html;
    }

    function BinderForm() {
        var $html = BuilFormFilter();
        $('#apiTable').html($html);
    }

    function CallAPI() {
        var inputdata = {};
        $('#apiTable').find('.datepicker').each(function () {
            inputdata[$(this).attr('id')] = new Date($(this).val()).valueOf();
        });
        inputdata['appId'] = drupalSettings.application.id;
        inputdata['size'] = $('#size').val();
        $.ajax({
            type: 'POST',
            url: drupalSettings.path.baseUrl + 'apianalytic/get',
            data: inputdata,
            beforeSend: function () {
                resetTable('lstSumary');
                resetTable('lst');
                resetTable('log');
            },
            success: function (obj) {
                if (obj.data != undefined) {
                    var objSerialize = JSON.parse(obj.data.content);
                    var data = [];
                    for (var i = 0; i < objSerialize.responses[0].hits.hits.length; i++) {
                        data.push(objSerialize.responses[0].hits.hits[i]._source);
                    }
                    var transationSumary = BuilDataTransactionSumary(data);
                    if (transationSumary.length > 0) {
                        buildHeader(transationSumary[0], 'lstSumary');
                        for (var i = 0; i < transationSumary.length; i++) {
                            buildBody(transationSumary[i], 'lstSumary');
                        }
                    }
                    BuildCanvasChart(transationSumary);
                    var transactionList = BuilDataListTransaction(data);
                    if (transactionList.length > 0) {
                        buildHeader(transactionList[0], 'lst');
                        for (var i = 0; i < transactionList.length; i++) {
                            buildBody(transactionList[i], 'lst');
                        }
                    }
                    
                    // buildHeader(objSerialize.responses[0].hits.hits[0]._source, 'log');
                    // for (var i = 0; i < objSerialize.responses[0].hits.hits.length; i++) {
                    //     buildBody(objSerialize.responses[0].hits.hits[i]._source, 'log');
                    // }
                }
            },
            error: function (err) {
                console.log(err);
            }
        });
    }
    Date.prototype.addDays = function (days) {
        var date = new Date(this.valueOf());
        date.setDate(date.getDate() + days);
        return date;
    }
    Date.prototype.addHours = function (h) {
        this.setTime(this.getTime() + (h * 60 * 60 * 1000));
        return this;
    }

    function sameDay(d1, d2) {
        return d1.getFullYear() === d2.getFullYear() &&
            d1.getMonth() === d2.getMonth() &&
            d1.getDate() === d2.getDate();
    }

    function BuilDataTransactionSumary(data) {
        var transactionsumary = [];
        var beginDate = new Date($('#fromDate').val());
        var endDate = new Date($('#toDate').val());
        var rangeDate = [];
        var rangeNameTrans = [];
        rangeDate.push(beginDate);
        var start = beginDate;
        if (beginDate == endDate) {
            rangeDate.push(beginDate);
        } else {
            while (start < endDate) {
                start = start.addDays(1);
                rangeDate.push(start);
            }
            //rangeDate.push(endDate);
        }

        for (var i = 0; i < data.length; i++) {
            var nameTransaction = data[i].uri_path.split('/')[data[i].uri_path.split('/').length - 1];
            var countHas = 0;
            for (var j = 0; j < rangeNameTrans.length; j++) {
                if (rangeNameTrans[j] == nameTransaction) {
                    countHas++;
                }
            }
            if (countHas == 0) {
                rangeNameTrans.push(nameTransaction);
            }
        }
        for (var d = 0; d < rangeDate.length; d++) {
            //var transName = '';
            var CountTransaction = 0;
            var PreCountTransaction = 0;
            var PreTotalAmount = 0;
            var TotalAmount = 0;
            var NetAmount = 0;
            var DatatransactionDate = rangeDate[d];
            var TransactionDate = rangeDate[d].toLocaleDateString();
            //for (k = 0; k < rangeNameTrans.length; k++) {
            //transName = rangeNameTrans[k];
            for (var i = 0; i < data.length; i++) {
                var obj = data[i];
                var dateTrans = new Date(obj.datetime);
                if (sameDay(dateTrans, DatatransactionDate)) {
                    if (obj.request_body.indexOf('tranferAmount') >= 0) {
                        CountTransaction++;
                    } else if (obj.request_body.indexOf('amount') >= 0) {
                        CountTransaction++;
                    }
                    if (obj.status_code.indexOf("200 OK") >= 0) {
                        if (obj.request_body.indexOf('tranferAmount') >= 0) {
                            var objectRequest = JSON.parse(obj.request_body);
                            TotalAmount += objectRequest.tranferAmount;
                            //NetAmount += objectRequest.tranferAmount;
                        } else if (obj.request_body.indexOf('amount') >= 0) {
                            var objectRequest = JSON.parse(obj.request_body);
                            TotalAmount += objectRequest.amount;
                            //NetAmount += objectRequest.amount;
                        }
                    }
                    else {
                        if (obj.request_body.indexOf('tranferAmount') >= 0) {
                            var objectRequest = JSON.parse(obj.request_body);
                            PreTotalAmount += objectRequest.tranferAmount;
                        } else if (obj.request_body.indexOf('amount') >= 0) {
                            var objectRequest = JSON.parse(obj.request_body);
                            PreTotalAmount += objectRequest.amount;
                        }
                    }
                }

            }
            //}
            transactionsumary.push({
                //transName,
                "Transaction Date": TransactionDate,
                "Count Transaction": CountTransaction,
                "Pre Count Transaction": PreCountTransaction,
                "Pre Total Amount": PreTotalAmount,
                "Post Total Amount": TotalAmount
                //NetAmount
            });
        }
        return transactionsumary;
    }

    function BuilDataListTransaction(data) {
        var transactionList = [];
        for (var i = 0; i < data.length; i++) {
            var obj = data[i];
            if (obj.request_body.indexOf('fastTransfer') >= 0 || obj.request_body.indexOf('externalTransfer') >= 0 || obj.request_body.indexOf('internalTransfer') >= 0 || obj.request_body.indexOf('billPaymentInfo') >= 0) {
                var transId = '';
                var TransactionType = '';
                var Card_AccountNum = '';
                var TransactionTime = '';
                var Status = '';
                var Amount = 0;
                var Description = '';
                var requestObject = JSON.parse(obj.request_body);
                transId = requestObject.trace.clientTransId;
                TransactionType = obj.request_method;
                if (obj.request_body.indexOf('fastTransfer') >= 0) {
                    Card_AccountNum = requestObject.data.fastTransfer.sourceAccountNumber;
                    Amount = requestObject.data.fastTransfer.tranferAmount;
                    Description = requestObject.data.fastTransfer.transferDescription;
                } else if (obj.request_body.indexOf('externalTransfer') >= 0) {
                    Card_AccountNum = requestObject.data.externalTransfer.sourceAccountNumber;
                    Amount = requestObject.data.externalTransfer.tranferAmount;
                    Description = requestObject.data.externalTransfer.transferDescription;
                } else if (obj.request_body.indexOf('internalTransfer') >= 0) {
                    Card_AccountNum = requestObject.data.internalTransfer.sourceAccountNumber;
                    Amount = requestObject.data.internalTransfer.tranferAmount;
                    Description = requestObject.data.internalTransfer.transferDescription;
                } else if (obj.request_body.indexOf('billPaymentInfo') >= 0) {
                    Card_AccountNum = requestObject.data.billPaymentInfo.debitAccount;
                    Amount = requestObject.data.billPaymentInfo.amount;
                    Description = requestObject.data.billPaymentInfo.transferDescription;
                }
                Status = obj.status_code;
                transactionList.push({
                    transId,
                    TransactionType,
                    Card_AccountNum,
                    TransactionTime,
                    Status,
                    Amount,
                    Description
                });
            }
        }
        return transactionList;
    }

    function BuildCanvasChart(transactionsumary) {
        var datapointSummaryPreAmount = [];
        var datapointSummaryPostAmount = [];
        transactionsumary.forEach(element => {
            datapointSummaryPreAmount.push({ label: element['Transaction Date'], y: element['Pre Total Amount'] });
            datapointSummaryPostAmount.push({ label: element['Transaction Date'], y: element['Post Total Amount'] });
        });
        
        var chart = new CanvasJS.Chart("chartContainer", {
            animationEnabled: true,
            title:{
                text: "Transaction Summary"
            },	
            axisY: {
                title: "Pre Amount",
                titleFontColor: "#C0504E",
                lineColor: "#C0504E",
                labelFontColor: "#C0504E",
                tickColor: "#C0504E"
            },
            axisY2: {
                title: "Post Amount",
                titleFontColor: "#4F81BC",
                lineColor: "#4F81BC",
                labelFontColor: "#4F81BC",
                tickColor: "#4F81BC"
            },	
            toolTip: {
                shared: true
            },
            legend: {
                cursor:"pointer",
                itemclick: toggleDataSeries
            },
            data: [{
                type: "column",
                name: "Pre Total Amount",
                legendText: "Pre Total Amount",
                showInLegend: true, 
                dataPoints:datapointSummaryPreAmount
            },
            {
                type: "column",	
                name: "Post Total Amount",
                legendText: "Post Total Amount",
                axisYType: "secondary",
                showInLegend: true,
                dataPoints: datapointSummaryPostAmount
            }]
        });
        chart.render();
    }
    
    function toggleDataSeries(e) {
        if (typeof(e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
            e.dataSeries.visible = false;
        }
        else {
            e.dataSeries.visible = true;
        }
        chart.render();
    }

    $(document).ready(function () {
        $('.datepicker').datepicker({
            format: 'yyyy-mm-dd'
        });
        $('#btnSearch').click(function () {
            CallAPI();
        });
        $('#size').change(function () {
            CallAPI();
        });

    });

}(jQuery));