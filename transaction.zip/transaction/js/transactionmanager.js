/********************************************************* {COPYRIGHT-TOP} ***
 * Licensed Materials - Property of IBM
 *
 * (C) Copyright IBM Corporation 2018, 2019
 *
 * All Rights Reserved.
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 ********************************************************** {COPYRIGHT-END} **/

/**
 * @file
 * Setup global config for analytics
 */

(function ($, Drupal, drupalSettings) {
    Drupal.behaviors.appAnalyticsConfig = {
        attach: function (context) 
        {
            var urlAPICall = '';
            urlAPICall = drupalSettings.analytics.proxyURL;
            if (drupalSettings.analytics && drupalSettings.analytics.analyticsDir) {
            window.apiConnectAnalytics = [];
            window.apiConnectAnalytics.options = [];
            window.apiConnectAnalytics.options.analyticsDir = drupalSettings.analytics.analyticsDir;
            }
    
            if (drupalSettings.analytics && drupalSettings.analytics.proxyURL) {
                let anv = new window.AnalyticsNativeVis({
                    settings: {
                    url: drupalSettings.analytics.proxyURL,
                    refreshRate: '1m'
                    },
                    user: {
                    context: {},
                    config: {}
                    }
                });
                if (!drupalSettings.anv) {
                    drupalSettings.anv = [];
                }
        
                if (!drupalSettings.anv.appIdFilter) {
                    drupalSettings.anv.appIdFilter = anv.createFilter({
                    "field": "app_id",
                    "values": [drupalSettings.application.id],
                    "selectedValue": drupalSettings.application.id
                    });
                }
        
                if (!drupalSettings.anv.apiStatsTimeId) {
                    drupalSettings.anv.apiStatsTimeId = anv.createTime({
                    "field": "datetime",
                    "values": ["30s", "1m", "30m", "1h", "1d", "7d", "30d"],
                    "selectedValue": "1d"
                    });
                }
        
                if (!drupalSettings.anv.static30dTime) {
                    drupalSettings.anv.static30dTime = anv.createTime({
                    "field": "datetime",
                    "values": ["30d"],
                    "selectedValue": "30d"
                    });
                }
        
                if (!drupalSettings.anv.static1hTime) {
                    drupalSettings.anv.static1hTime = anv.createTime({
                    "field": "datetime",
                    "values": ["1h"],
                    "selectedValue": "1h"
                    });
                }
        
                if (!drupalSettings.anv.apiCallsWidget) {
                    debugger;
                    drupalSettings.anv.apiCallsWidget = anv.createWidget({
                    "id": "api-calls",
                    "time": drupalSettings.anv.static30dTime,
                    "timeType": "single",
                    "filters": [drupalSettings.anv.appIdFilter],
                    "vis": [{
                        "type": "info",
                        "metrics": [{
                        "type": "raw",
                        "size": 1000
                        }],
                        "metadata": {
                        "path": "_uri_path_",
                        "date": "_datetime_",
                        "responseCode": "_status_code_",
                        "title": "_request_method_",
                        "averageTime": "_time_to_serve_request_"
                        }
                    }],
                    "metadata": {
                        "scrollable": true,
                        "title": "My module show",
                        "height": "100%"
                    }
                    });
                }
        
                if (!drupalSettings.anv.apiCallsErrorsWidget) {
                    drupalSettings.anv.apiCallsErrorsWidget = anv.createWidget({
                    "id": "api-calls-errors",
                    "time": drupalSettings.anv.static30dTime,
                    "timeType": "single",
                    "filters": [drupalSettings.anv.errorFilter, drupalSettings.anv.appIdFilter],
                    "vis": [{
                        "type": "info",
                        "metrics": [{
                        "type": "raw",
                        "size": 100
                        }],
                        "metadata": {
                        "path": "_uri_path_",
                        "date": "_datetime_",
                        "responseCode": "_status_code_",
                        "title": "_request_method_",
                        "averageTime": "_time_to_serve_request_"
                        }
                    }],
                    "metadata": {
                        "scrollable": true,
                        "title": drupalSettings.analytics.translations.errors_last_100,
                        "height": "100%"
                    }
                    });
                }


                var htmlBuilder = "";
                var ajaxResponse;
                var xhrArgs = 
                {
                    url: drupalSettings.analytics.proxyURL,
                    handleAs: "json",
                    noload: function(serverResponse)
                    {
                        console.log("success!");
                        ajaxResponse = serverResponse;
                        for (i = 0; i < ajaxResponse.Properties.length; i++)
                        {
                            if(ajaxResponse.Properties[i].SymbolicName.indexOf('_') != -1)
                            {
                                if (ajaxResponse.Properties[i].PropertyType == "boolean")
                                {
                                    htmlBuilder += "<h3>" + ajaxResponse.Properties[i].DisplayName + "(" + ajaxResponse.Properties[i].PropertyType + ")</h3>";
                                    htmlBuilder += "<form>";
                                    htmlBuilder += 'true<input type="radio" size="25" id ="' +
                                    ajaxResponse.Properties[i].DisplayName + '-true" value="true"><br/>';
                                    htmlBuilder += 'false<input type="radio" size="25" id ="' +
                                    ajaxResponse.Properties[i].DisplayName + '-false" value="false"><br/>';
                                    htmlBuilder += "</form>";
                                }
                                else
                                {
                                    htmlBuilder += "<h3>" + ajaxResponse.Properties[i].DisplayName + "(" + ajaxResponse.Properties[i].PropertyType + ")</h3>";
                                    htmlBuilder += '<input type="text" size="25" id ="' + ajaxResponse.Properties[i].DisplayName + '">';
                                }
                            }
                        }
                        dojo.byId("Wrapper").innerHTML = htmlBuilder;
                    },
                    error:function(error){
                        console.log('error!' + error);
                    }
                }
                alert(urlAPICall);
                if (document.getElementById('apicallhistory')) {
                    anv.render(drupalSettings.anv.apiCallsWidget, document.getElementById('apicallhistory'));
                }
                else {
                    console.log("drupalSettings.analytics.proxyURL is not set");
                }
            } 
        }
    };
})(jQuery, Drupal, drupalSettings);
  
  
  